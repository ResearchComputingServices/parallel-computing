img = imread('hubble_orion_nebula.jpg');

figure;
imshow(img);

processimage_vectorized;

figure;
imshow(img);
